cat /proc/sys/net/ipv4/ip_forward # harus 1

# konfig eonwe
up apt update && apt install iptables -y
up iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE -s 10.82.0.0/16

# konfig client
up echo "nameserver 192.168.122.1" > /etc/resolv.conf

# cara cek di semua node 
ping -c 3 google.com
