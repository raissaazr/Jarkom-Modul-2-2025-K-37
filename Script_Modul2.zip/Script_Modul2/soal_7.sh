# di Tirion
sudo nano /etc/bind/db.k37.com

; CNAME Records
www     IN      CNAME   sirion.K37.com.  
static  IN      CNAME   lindon.K37.com.
app     IN      CNAME   vingilot.K37.com.

sudo named-checkzone K37.com /etc/bind/db.K37.com

# di tirion dan valmar
/etc/init.d/named restart

# Di terminal earendil (atau host manapun)
# Verifikasi CNAME: Harus resolve melalui alias
dig www.K37.com       # 10.82.3.2 (sirion.k37.com)
dig static.K37.com    # 10.82.3.5 (lindon.k37.com)
dig app.K37.com       # 10.82.3.6 (vingilot.k37.com)


