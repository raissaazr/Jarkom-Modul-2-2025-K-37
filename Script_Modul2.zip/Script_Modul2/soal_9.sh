# di Lindon
apt update && apt install apache2 -y

# Buat direktori arsip yang diminta
mkdir -p /var/www/K37.com/annals

# Buat beberapa file dummy untuk menguji directory listing
touch /var/www/K37.com/annals/arsip1.txt
touch /var/www/K37.com/annals/dokumen_penting.pdf

# Atur kepemilikan agar apache dapat membacanya
chown -R www-data:www-data /var/www/K37.com

nano /etc/apache2/sites-available/static.K37.com.conf
<VirtualHost *:80>
    ServerName static.K37.com
    ServerAdmin webmaster@K37.com
    DocumentRoot /var/www/K37.com

    <Directory /var/www/K37.com/annals/>
        Options +Indexes
        AllowOverride None
        Require all granted
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/error.log
    CustomLog ${APACHE_LOG_DIR}/access.log combined
</VirtualHost>

a2ensite static.K37.com.conf
/etc/init.d/apache2 restart

# di earendil
dig static.k37.com
curl static.K37.com/annals/