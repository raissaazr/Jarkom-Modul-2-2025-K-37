# Tirion
apt update && apt install bind9 -y
nano /etc/bind/named.conf.local
options {
    directory "/var/cache/bind";
    forwarders {
        192.168.122.1;
    };
    allow-query{any;};
    listen-on { 10.82.3.3; 127.0.0.1; };
};

// Definisi Zona Master
zone "K37.com" {
    type master;
    file "/etc/bind/db.K37.com";
    allow-transfer { 10.82.3.4; }; 
    notify yes; 
};

nano /etc/bind/db.K37.com
$TTL    604800
@       IN      SOA     ns1.K37.com. root.K37.com. (
                              2025101301 ; Serial (Harus dinaikkan jika ada perubahan!)
                              604800     ; Refresh
                               86400     ; Retry
                            2419200      ; Expire
                              604800 )   ; Negative Cache TTL

@       IN      NS      ns1.K37.com.
@       IN      NS      ns2.K37.com.

; A Record untuk Nameserver
ns1     IN      A       10.82.3.3
ns2     IN      A       10.82.3.4

; A Record Apex (Front Door)
@       IN      A       10.82.3.2

# cek 
named-checkzone K37.com /etc/bind/db.K37.com
named-checkconf
/etc/init.d/named restart

# Valmar
apt update && apt install bind9 -y
nano /etc/bind/named.conf.local
options {
    directory "/var/cache/bind";
    forwarders {
        192.168.122.1;
    };
    allow-query{any;};
    listen-on { 10.82.3.4; 127.0.0.1; };
};

zone "K37.com" {
    type slave;
    file "db.K37.com";
    masters { 10.82.3.3; }; 
};

named-checkconf
/etc/init.d/named restart

dig @127.0.0.1 K37.com

# Di terminal Earendil, Elwing, Sirion, Tirion, dst.
sudo apt update 
sh -c 'echo "nameserver 10.82.3.3" > /etc/resolv.conf'
sh -c 'echo "nameserver 10.82.3.4" >> /etc/resolv.conf'
sh -c 'echo "nameserver 192.168.122.1" >> /etc/resolv.conf'
dig K37.com
dig google.com 


