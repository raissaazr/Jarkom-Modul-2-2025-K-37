hostname eonwe
hostname earendil
hostname elwing
hostname cirdan
hostname maglor
hostname elrond
hostname sirion
hostname tirion
hostname valmar
hostname lindon
hostname vingilot

hostname

# di tirion
sudo nano /etc/bind/db.K37.com
2025101202 ; Serial (Tingkatkan angka terakhir)
eonwe  IN      A        10.82.3.1
earendil IN      A       10.82.1.2
elwing  IN      A       10.82.1.3
cirdan  IN      A       10.82.2.2
elrond  IN      A       10.82.2.3
maglor  IN      A       10.82.2.4
sirion IN       A       10.82.3.2
tirion  IN      A       10.82.3.3
valmar  IN      A       10.82.3.4
lindon  IN      A       10.82.3.5
vingilot IN      A       10.82.3.6

named-checkzone K37.com /etc/bind/db.K37.com

# di Tirion dan Valmar
/etc/init.d/named restart

# Di terminal Earendil (atau host manapun)
dig eonwe.K37.com
dig lindon.K37.com

# Di terminal Earendil (atau host manapun)
ping lindon.K37.com -c 4