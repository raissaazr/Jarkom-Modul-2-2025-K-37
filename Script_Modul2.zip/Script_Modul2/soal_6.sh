# di tirion
dig @127.0.0.1 K37.com SOA

# di valmar
dig @127.0.0.1 K37.com SOA
dig eonwe.K37.com

