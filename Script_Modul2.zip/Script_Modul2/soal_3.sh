
# cara cek 
ping -c 3 10.82.1.3
ping -c 3 10.82.2.2
ping -c 3 10.82.3.2
ping -c 3 10.82.2.5
