# di sirion & vingilot
apt update && apt install apache2 -y

# di vingilot
apt install php-fpm libapache2-mod-fcgid -y
mkdir -p /var/www/vingilot
nano /var/www/vingilot/index.php
<?php
echo "<h1>Beranda Vingilot</h1>";
echo "<p>Web Dinamis Vingilot berhasil dijalankan. Tanggal Server: " . date("Y-m-d H:i:s") . "</p>";
?>

nano /var/www/vingilot/about.php
<?php
echo "<h1>Tentang Vingilot</h1>";
echo "<p>Ini adalah halaman About kami.</p>";
?>

chown -R www-data:www-data /var/www/vingilot

nano /etc/apache2/sites-available/app.K37.com.conf
<VirtualHost *:8080>
    ServerName app.K37.com
    ServerAdmin webmaster@K37.com
    DocumentRoot /var/www/vingilot

    <FilesMatch \.php$>
        SetHandler "proxy:fcgi://127.0.0.1:9000"
    </FilesMatch>

    <Directory /var/www/vingilot/>
        AllowOverride All
        Require all granted
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/app-error.log
    CustomLog ${APACHE_LOG_DIR}/app-access.log combined
</VirtualHost>

a2enmod proxy_fcgi setenvif
a2ensite app.K37.com.conf
/etc/init.d/apache2 restart
/etc/init.d/php8.4-fpm restart

# di sirion
a2enmod rewrite
nano /etc/apache2/sites-available/app.K37.com.conf
<VirtualHost *:80>
    ServerName app.K37.com
    ServerAdmin webmaster@K37.com

    ProxyPreserveHost On
    ProxyRequests Off

    ProxyPass / http://10.82.3.6:8080/
    ProxyPassReverse / http://10.82.3.6:8080/

    RewriteEngine On
    RewriteRule ^/about$ /about.php [P,L]

    ErrorLog ${APACHE_LOG_DIR}/app-error.log
    CustomLog ${APACHE_LOG_DIR}/app-access.log combined
</VirtualHost>

a2dissite 000-default.conf
a2ensite app.k37.com.conf
/etc/init.d/apache2 restart

# di earendil 
curl app.K37.com 