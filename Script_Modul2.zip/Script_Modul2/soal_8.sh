# di tirion
nano /etc/bind/named.conf.local

# Tambahkan di /etc/bind/named.conf.local (Tirion)
zone "3.82.10.in-addr.arpa" {
    type master;
    file "/etc/bind/db.10.82.3";
    allow-transfer { 10.82.3.4; };
    notify yes;
};

# Buat file baru untuk menyimpan PTR record
nano /etc/bind/db.10.82.3
$TTL    604800
@       IN      SOA     ns1.k37.com. root.k37.com. (
                              2025101301 ; Serial
                              604800     ; Refresh
                               86400     ; Retry
                            2419200      ; Expire
                              604800 )   ; Negative Cache TTL

@       IN      NS      ns1.k37.com.
@       IN      NS      ns2.k37.com.

; PTR Records untuk Host Server di DMZ
2       IN      PTR     sirion.k37.com.    ; 10.82.3.2
5       IN      PTR     lindon.k37.com.    ; 10.82.3.5
6       IN      PTR     vingilot.k37.com.  ; 10.82.3.6

# Cek sintaks
named-checkzone 3.82.10.in-addr.arpa /etc/bind/db.10.82.3
/etc/init.d/named restart

# di valmar
nano /etc/bind/named.conf.local

# Tambahkan di /etc/bind/named.conf.local (Valmar)
zone "3.82.10.in-addr.arpa" {
    type slave;
    file "db.10.82.3";
    masters { 10.82.3.3; }; // Tirion (ns1) adalah Master
};

/etc/init.d/named restart

# uji di earendil (atau host manapun)
dig -x 10.82.3.2 @10.82.3.3 #sirion.k37.com.
dig -x 10.82.3.5 @10.82.3.4 #lindon.k37.com.
dig -x 10.82.3.6 @10.82.3.3 #vingilot.k37.com.


