# IP_LINDON
10.82.3.5

# Install nginx secara manual
tee /root/install_nginx_nosystemd.sh > /dev/null <<'EOF'
#!/bin/bash
set -e

# Update repos
apt update

# Install nginx
DEBIAN_FRONTEND=noninteractive apt install -y nginx

echo "nginx installed successfully (no systemctl available)."
EOF

chmod +x /root/install_nginx_nosystemd.sh

# Jalankan
/root/install_nginx_nosystemd.sh

# Buat konfigurasi web statis
tee /root/create_static_site_nosystemd.sh > /dev/null <<'EOF'
#!/bin/bash
set -e

GROUP="K37"
IP_LINDON="10.82.3.5"

SITE_ROOT="/var/www/annals"
SITE_CONF="/etc/nginx/sites-enabled/static.${GROUP}.conf"

# pastikan folder log dan config ada
mkdir -p /var/log/nginx
mkdir -p /etc/nginx/sites-enabled

# Buat direktori web
mkdir -p ${SITE_ROOT}/annals
chown -R www-data:www-data /var/www

# File index utama
cat > ${SITE_ROOT}/index.html <<HTML
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>static.${GROUP}.com - Lindon</title>
</head>
<body>
  <h1>Halo dari Lindon!</h1>
  <p>Ini web statis untuk kelompok ${GROUP}</p>
  <p><a href="/annals/">Lihat folder /annals</a></p>
</body>
</html>
HTML

# Isi folder annals
for i in {1..3}; do
  echo "Catatan ke-${i}" > ${SITE_ROOT}/annals/note${i}.txt
done

# Buat config nginx
cat > ${SITE_CONF} <<NGCONF
events {}

http {
    access_log /var/log/nginx/access.log;
    error_log /var/log/nginx/error.log;

    server {
        listen 80;
        server_name static.${GROUP}.com;

        root ${SITE_ROOT};
        index index.html;

        location = /annals {
            return 301 /annals/;
        }

        location /annals/ {
            autoindex on;
            autoindex_exact_size off;
            autoindex_localtime on;
        }

        location / {
            try_files \$uri \$uri/ =404;
        }
    }

    # default reject if accessed via IP
    server {
        listen 80 default_server;
        server_name _;
        return 444;
    }
}
NGCONF

# Matikan nginx lama jika ada
pkill nginx || true

# Jalankan nginx manual
/usr/sbin/nginx -c ${SITE_CONF} -g "daemon off;" &
echo "Nginx started manually using config: ${SITE_CONF}"
echo "Tes di browser (atau curl): http://static.${GROUP}.com/"
EOF

chmod +x /root/create_static_site_nosystemd.sh

# Jalankan
/root/create_static_site_nosystemd.sh

# Tes nginx berjalan atau belum
curl -s -H "Host: static.K37.com" http://127.0.0.1/ | head -n 10

# Tes autoindex
curl -s -H "Host: static.K37.com" http://127.0.0.1/annals/ | head -n 20

# Menjaga nginx tetap hidup setelah reboot
tee /root/run.sh > /dev/null <<'EOF'
#!/bin/bash
# Jalankan nginx manual saat node start
/usr/sbin/nginx -c /etc/nginx/sites-enabled/static.K01.conf -g "daemon off;"
EOF

chmod +x /root/run.sh

# Akses dari klien
# IP_ELROND
10.82.2.3

# Tambahkan entri di /etc/hosts klien
bash -c 'echo "10.82.2.3 static.K37.com" >> /etc/hosts'

# Untuk memastikan berhasil
cat /etc/hosts

# Coba ping untuk memastikan
ping -c 3 static.K37.com